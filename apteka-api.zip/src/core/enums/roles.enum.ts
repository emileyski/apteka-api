export enum Roles {
  ADMIN = 'admin',
  SELLER = 'seller',
}
